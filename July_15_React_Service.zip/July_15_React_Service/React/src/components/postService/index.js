import postService from "./postService"
export default postService;
