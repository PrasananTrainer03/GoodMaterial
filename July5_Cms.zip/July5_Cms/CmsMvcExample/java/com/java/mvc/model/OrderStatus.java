package com.java.mvc.model;

public enum OrderStatus {

	ACCEPTED, DENIED, PENDING
}
