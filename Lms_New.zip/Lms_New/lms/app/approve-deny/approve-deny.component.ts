import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approve-deny',
  templateUrl: './approve-deny.component.html',
  styleUrls: ['./approve-deny.component.css']
})
export class ApproveDenyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
