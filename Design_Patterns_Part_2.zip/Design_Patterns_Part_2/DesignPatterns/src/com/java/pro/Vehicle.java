package com.java.pro;

public interface Vehicle {
	Vehicle getClone();
}
