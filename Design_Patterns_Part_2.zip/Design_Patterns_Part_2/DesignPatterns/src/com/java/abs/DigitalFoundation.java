package com.java.abs;

public class DigitalFoundation implements Training {

	public final String topic;
	
	public DigitalFoundation() {
		topic="Digital Foundation Topic";
	}
	@Override
	public String getTrainingDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
