package com.java.abs;

public interface Training {
	String getTrainingDetails();
}
