package com.java.facade;

public interface Training {
	String topic();
	int duration();
	String trainerInfo();
}
