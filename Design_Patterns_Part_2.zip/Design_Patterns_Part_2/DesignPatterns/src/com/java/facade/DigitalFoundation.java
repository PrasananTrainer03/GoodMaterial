package com.java.facade;

public class DigitalFoundation implements Training {

	@Override
	public String topic() {
		return "Digital Foundation...Java/Python/Mysql...";
	}

	@Override
	public int duration() {
		// TODO Auto-generated method stub
		return 28;
	}

	@Override
	public String trainerInfo() {
		// TODO Auto-generated method stub
		return "Trainer is Mr. Chandra Sekhar...";
	}

}
