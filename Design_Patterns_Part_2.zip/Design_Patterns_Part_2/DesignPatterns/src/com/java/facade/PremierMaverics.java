package com.java.facade;

public class PremierMaverics implements Training {

	@Override
	public String topic() {
		return "Premier Maverics, Java/Spring/SpringBoot/Angular...";
	}

	@Override
	public int duration() {
		// TODO Auto-generated method stub
		return 32;
	}

	@Override
	public String trainerInfo() {
		// TODO Auto-generated method stub
		return "Trainer is MS. Pallavi Prasad...";
	}

}
