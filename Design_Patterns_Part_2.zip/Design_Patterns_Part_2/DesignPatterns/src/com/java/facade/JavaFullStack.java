package com.java.facade;

public class JavaFullStack implements Training {

	@Override
	public String topic() {
		return "JavaFull Stack Spring/Hibernate/CI/CD/React...";
	}

	@Override
	public int duration() {
		// TODO Auto-generated method stub
		return 26;
	}

	@Override
	public String trainerInfo() {
		// TODO Auto-generated method stub
		return "Trainer is Mr. Prasanna Pappu...";
	}

}
