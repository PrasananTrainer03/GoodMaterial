export class Customer {
    public cusId : number;
    public cusName : string;
    public cusPhnNo : string;
    public cusUsername : string;
    public cusPassword : string;
    public cusEmail : string;
    constructor() {

    }
}
