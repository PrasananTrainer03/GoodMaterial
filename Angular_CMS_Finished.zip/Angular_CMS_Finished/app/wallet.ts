export class Wallet {
    public cusId : number;
    public walId : number;
    public walSource : string;
    public walAmount : number;
    constructor() {

    }
}
