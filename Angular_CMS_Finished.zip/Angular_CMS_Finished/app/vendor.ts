export class Vendor {
    public venId : number;
    public venName : string;
    public venPhnNo : string;
    public venUsername : string;
    public venPassword : string; 
    public venEmail : string;
    constructor() {

    }
}
