package com.java.spr;

public interface Hello {

	String sayHello(String name);
}
