package com.java.jdbc;

public enum Gender {

	MALE, FEMALE
}
