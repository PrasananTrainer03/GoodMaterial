package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJdbcEmployExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJdbcEmployExampleApplication.class, args);
	}

}
