package com.java.cms;

public enum OrderStatus {

	ACCEPTED, DENIED, PENDING
}
