package com.java.cms;

public enum WalSource {

	PAYTM, CREDIT_CARD, DEBIT_CARD
}
