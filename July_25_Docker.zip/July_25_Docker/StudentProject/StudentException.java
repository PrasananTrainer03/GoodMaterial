

public class StudentException extends Exception {

	StudentException() {}
	
	StudentException(String error) {
		super(error);
	}
}
