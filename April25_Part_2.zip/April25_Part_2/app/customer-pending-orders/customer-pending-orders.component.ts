import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-pending-orders',
  templateUrl: './customer-pending-orders.component.html',
  styleUrls: ['./customer-pending-orders.component.css']
})
export class CustomerPendingOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
