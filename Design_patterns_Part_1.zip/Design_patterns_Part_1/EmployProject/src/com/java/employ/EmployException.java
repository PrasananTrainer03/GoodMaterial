package com.java.employ;

public class EmployException extends Exception {

	EmployException(String error) {
		super(error);
	}
}
