package com.java.abs;

public class JavaFullStack implements Training {

	public final String topic;
	
	public JavaFullStack() {
		topic="FullStack Topics Java/Spring-Hibernate/React/CI/CD/Microservices";
	}
	
	@Override
	public String getTrainingDetails() {
		// TODO Auto-generated method stub
		return topic;
	}

}
