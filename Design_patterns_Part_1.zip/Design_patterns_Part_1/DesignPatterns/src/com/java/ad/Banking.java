package com.java.ad;

public interface Banking {

	void storeCustomerInfo();
	String printAllInfo();
}
