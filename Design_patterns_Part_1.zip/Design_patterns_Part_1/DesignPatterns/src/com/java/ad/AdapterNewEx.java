package com.java.ad;

public class AdapterNewEx {

}
