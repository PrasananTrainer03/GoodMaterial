package com.java.ad;

public class AdapterMain2 {

	public static void main(String[] args) {
		Banking obj = new Maheswari();
		obj.storeCustomerInfo();
		System.out.println(obj.printAllInfo());
	}
}
