package com.java.ad;

public interface AgentDetails {

	void storePersonalDetails();
	String getPremiumAndPersonalDetails();
	//AgentDetails showAgentInfo();
}
