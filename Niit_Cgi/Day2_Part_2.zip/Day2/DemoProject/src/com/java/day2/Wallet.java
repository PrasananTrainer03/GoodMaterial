package com.java.day2;

public enum Wallet {
    PAYTM, PHONEPE, GPAY
}
