package com.java.cons;

public class ConEmploy {

    public static void main(String[] args) {
        Employ emp1 = new Employ();
        System.out.println(emp1);
        Employ emp2 = new Employ(3, "Vikram", 84255);
        System.out.println(emp2);
    }
}
