package com.java.cons;

public enum Gender {
    MALE, FEMALE
}
