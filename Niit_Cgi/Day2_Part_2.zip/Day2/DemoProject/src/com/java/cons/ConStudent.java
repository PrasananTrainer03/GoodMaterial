package com.java.cons;

public class ConStudent {

    public static void main(String[] args) {
        Student s1 = new Student();
        System.out.println(s1);
        Student s2 = new Student(12, "Sowmya", "Hyderabad", 9.2);
        System.out.println(s2);
    }
}
