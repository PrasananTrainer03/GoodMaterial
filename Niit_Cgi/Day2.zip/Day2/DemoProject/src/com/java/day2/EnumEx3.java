package com.java.day2;

public class EnumEx3 {
    public static void main(String[] args) {
        Wallet wal = Wallet.PHONEPE;
        System.out.println(wal);
    }
}








