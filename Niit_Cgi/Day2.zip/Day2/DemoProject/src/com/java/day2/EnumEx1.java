package com.java.day2;

public class EnumEx1 {

    public static void main(String[] args) {
        WeekDays wd1 = WeekDays.TUESDAY;
        System.out.println(wd1);
    }
}
