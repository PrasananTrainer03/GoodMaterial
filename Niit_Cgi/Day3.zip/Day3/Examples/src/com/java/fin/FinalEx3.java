package com.java.fin;

final class Admin {

}

//class Hr extends Admin {
//
//}
public class FinalEx3 {

}
