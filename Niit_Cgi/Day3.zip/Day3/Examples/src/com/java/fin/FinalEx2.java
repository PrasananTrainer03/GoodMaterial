package com.java.fin;

class First {
    public final void show() {
        System.out.println("Show From First...");
    }
}

class Second extends First {
//    public void show() {
//        System.out.println("Show From Second...");
//    }
}
public class FinalEx2 {
    public static void main(String[] args) {

    }
}
