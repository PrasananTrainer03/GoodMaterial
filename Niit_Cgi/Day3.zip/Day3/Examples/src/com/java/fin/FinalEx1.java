package com.java.fin;

public class FinalEx1 {
    final String comapny = "CGI";

    public static void main(String[] args) {
        System.out.println(new FinalEx1().comapny);
        FinalEx1 obj = new FinalEx1();
     //   obj.comapny="Hexaware";
    }
}
