package com.java.day1;

class Demo {

    public void irfan() {
        System.out.println("Hi I am Irfan...");
    }

    private void rithisree() {
        System.out.println("Hi I am Rithisree...");
    }

    void rohit() {
        System.out.println("Hi I am Rohit...");
    }
}

public class Data {
    public static void main(String[] args) {
        Demo obj = new Demo();
        obj.irfan();
        obj.rohit();
    }
}
