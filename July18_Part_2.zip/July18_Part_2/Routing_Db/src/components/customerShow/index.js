import customerShow from "./customerShow"
export default customerShow;
