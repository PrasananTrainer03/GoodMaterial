export class Orders {

    public ordId : number;
    public cusId : number;
    public venId : number;
    public menId : number;
    public walSource : number;
    public ordQuantity : number;
    public ordBillamount : number;
    public ordStatus : string;
    public ordComments : string;
    constructor() {

    }
}
