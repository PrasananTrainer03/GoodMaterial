import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-dash-board',
  templateUrl: './vendor-dash-board.component.html',
  styleUrls: ['./vendor-dash-board.component.css']
})
export class VendorDashBoardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
