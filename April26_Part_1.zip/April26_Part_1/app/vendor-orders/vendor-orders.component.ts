import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-orders',
  templateUrl: './vendor-orders.component.html',
  styleUrls: ['./vendor-orders.component.css']
})
export class VendorOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
