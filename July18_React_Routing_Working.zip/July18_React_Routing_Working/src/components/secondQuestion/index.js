import secondQuestion from "./secondQuestion"
export default secondQuestion;
