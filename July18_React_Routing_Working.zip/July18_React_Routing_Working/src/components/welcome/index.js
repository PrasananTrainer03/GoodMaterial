import welcome from "./welcome"
export default welcome;
