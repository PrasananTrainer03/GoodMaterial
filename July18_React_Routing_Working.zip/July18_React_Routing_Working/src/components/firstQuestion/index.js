import firstQuestion from "./firstQuestion"
export default firstQuestion;
