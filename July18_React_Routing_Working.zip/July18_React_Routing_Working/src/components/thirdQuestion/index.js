import thirdQuestion from "./thirdQuestion"
export default thirdQuestion;
