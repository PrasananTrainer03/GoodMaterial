package com.java.spr;

public interface Person {

	String showAllInfo();
}
