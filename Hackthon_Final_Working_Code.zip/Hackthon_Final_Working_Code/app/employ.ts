export class Employ {
    public empId : number; 
    public empName : string; 
    public empMobile : string; 
    public empEmail : string; 
    public empDptName : string; 
    public empDateOfJoin : string; 
    public empMgrId : number; 
    public empLeaveBalance : number;
}
